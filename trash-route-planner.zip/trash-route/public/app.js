'use strict';

// ------------------------------------------------------------------ helpers
const $ = (id) => document.getElementById(id);
const el = (tag, cls, html) => {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (html != null) e.innerHTML = html;
  return e;
};
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) =>
  ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

let toastTimer;
function toast(msg) {
  const t = $('toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), 3200);
}

let teamKey = (typeof localStorage !== 'undefined' && localStorage.getItem('teamKey')) || '';
async function api(path, opts) {
  opts = opts || {};
  const headers = Object.assign({ 'Content-Type': 'application/json' }, opts.headers || {});
  if (teamKey) headers['X-Team-Key'] = teamKey;
  let res = await fetch(path, Object.assign({}, opts, { headers }));
  if (res.status === 401) {
    const key = prompt('This app is protected. Enter the team key:') || '';
    if (key) {
      teamKey = key;
      localStorage.setItem('teamKey', key);
      headers['X-Team-Key'] = key;
      res = await fetch(path, Object.assign({}, opts, { headers }));
    }
  }
  let data = null;
  try { data = await res.json(); } catch (e) { /* not json */ }
  if (!res.ok) throw new Error((data && data.error) || ('HTTP ' + res.status));
  return data;
}

// ---------------------------------------------------------------- driver id
function getDriver() { return localStorage.getItem('driverName') || ''; }
function promptDriver() {
  const n = (prompt('Driver name (shown on the tracking sheet):', getDriver()) || '').trim();
  if (n) { localStorage.setItem('driverName', n); updateDriverUI(); return true; }
  return false;
}
function updateDriverUI() {
  const d = getDriver();
  const chip = $('driverChip');
  if (chip) chip.textContent = d ? ('👤 ' + d) : '👤 Set driver';
  const rd = $('runDriver');
  if (rd) rd.textContent = d ? ('Driver: ' + d) : '';
}

function fmtDur(sec) {
  if (!isFinite(sec)) return '—';
  const m = Math.round(sec / 60);
  if (m < 60) return m + ' min';
  const h = Math.floor(m / 60), mm = m % 60;
  return h + ' hr ' + mm + ' min';
}
function fmtDist(m) {
  if (!isFinite(m)) return '—';
  const mi = m / 1609.344;
  return mi < 10 ? mi.toFixed(1) + ' mi' : Math.round(mi) + ' mi';
}
function shortAddr(a) {
  const s = String(a || '').trim();
  const comma = s.indexOf(',');
  return (comma > 4 ? s.slice(0, comma) : s).slice(0, 44);
}

// ------------------------------------------------------------------ state
const state = {
  draft: { name: '', addresses: [] },
  geocoded: [],           // {id, address, ok, lat, lon, displayName, error}
  options: { roundtrip: false, minimizeLeftTurns: false, leftStrength: 'med',
             preferPassengerSide: false, sideStrength: 'med' },
  currentRouteId: null,
  currentRoute: null,     // saved payload
  runIndex: 0,
};

let seq = 0;
const nid = () => 's' + (++seq) + '_' + Date.now().toString(36);

// ------------------------------------------------------------------ map
let map = null;
function ensureMap() {
  if (map) return map;
  map = L.map('map', { zoomControl: true, attributionControl: true });
  L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
    attribution: '&copy; OpenStreetMap &copy; CARTO',
    subdomains: 'abcd',
    maxZoom: 19,
  }).addTo(map);
  return map;
}

let routeLayer = null, stopLayer = null;
function clearMapLayers() {
  if (routeLayer) { routeLayer.remove(); routeLayer = null; }
  if (stopLayer) { stopLayer.remove(); stopLayer = null; }
}

function stopIcon(n, kind) {
  kind = kind || 'pending';
  const colors = {
    pending: ['#ffb454', '#241300'],
    now: ['#3ddc84', '#062312'],
    done: ['#2f7d5b', '#0c1f16'],
    missed: ['#ff5c5c', '#2a0c0c'],
    skipped: ['#8b94a7', '#15181f'],
  };
  const [bg, fg] = colors[kind] || colors.pending;
  return L.divIcon({
    className: '',
    html: `<div style="width:30px;height:30px;border-radius:50%;background:${bg};color:${fg};
      border:2px solid rgba(255,255,255,.85);display:flex;align-items:center;justify-content:center;
      font-weight:800;font-size:13px;box-shadow:0 1px 4px rgba(0,0,0,.5);${kind === 'now' ? 'box-shadow:0 0 0 6px rgba(61,220,132,.25);' : ''}">${n}</div>`,
    iconSize: [34, 34],
    iconAnchor: [17, 17],
  });
}

function drawResultMap(route) {
  const m = ensureMap();
  clearMapLayers();
  const bounds = [];
  routeLayer = L.layerGroup().addTo(m);
  stopLayer = L.layerGroup().addTo(m);
  if (route.geometry && route.geometry.length) {
    L.polyline(route.geometry, { color: '#ffb454', weight: 5, opacity: .9 }).addTo(routeLayer);
    bounds.push(route.geometry[0], route.geometry[route.geometry.length - 1]);
  }
  for (const st of route.stops) {
    const ll = st.snapped ? [st.snapped[0], st.snapped[1]] : [st.lat, st.lon];
    if (st.snapped) bounds.push(ll);
    const mk = L.marker(ll, { icon: stopIcon(st.order, 'pending') }).addTo(stopLayer);
    mk.bindPopup(`<b>#${st.order}</b> — ${esc(shortAddr(st.address))}<br><span style="font-size:12px">${esc(sideLabel(st))}</span>`);
  }
  if (bounds.length) m.fitBounds(L.latLngBounds(bounds), { padding: [40, 40] });
}

function drawRunMap(route, currentIdx) {
  const m = ensureMap();
  clearMapLayers();
  routeLayer = L.layerGroup().addTo(m);
  stopLayer = L.layerGroup().addTo(m);
  const bounds = [];
  if (route.geometry && route.geometry.length) {
    L.polyline(route.geometry, { color: '#2a3242', weight: 6, opacity: .9 }).addTo(routeLayer);
    bounds.push(route.geometry[0], route.geometry[route.geometry.length - 1]);
  }
  // traveled portion: from start to current snapped point (approx by leg ends)
  const legPts = route.stops.filter((s) => s.order <= currentIdx + 1 && s.snapped).map((s) => s.snapped);
  if (legPts.length >= 2) {
    L.polyline(legPts, { color: '#3ddc84', weight: 5, opacity: .85 }).addTo(routeLayer);
  }
  for (const st of route.stops) {
    const ll = st.snapped ? [st.snapped[0], st.snapped[1]] : [st.lat, st.lon];
    bounds.push(ll);
    const rec = state.currentRoute.log[st.id];
    const status = rec ? rec.status : 'pending';
    let kind = 'pending';
    if (st.order - 1 === currentIdx) kind = 'now';
    else if (status === 'picked_up') kind = 'done';
    else if (status === 'missed') kind = 'missed';
    else if (status === 'skipped') kind = 'skipped';
    const mk = L.marker(ll, { icon: stopIcon(st.order, kind) }).addTo(stopLayer);
    mk.bindPopup(`<b>#${st.order}</b> — ${esc(shortAddr(st.address))}<br><span style="font-size:12px">${esc(sideLabel(st))} · ${esc(statusLabel(status))}</span>`);
  }
  if (bounds.length) m.fitBounds(L.latLngBounds(bounds), { padding: [30, 30] });
}

// ------------------------------------------------------------------ screens
function showScreen(name) {
  document.querySelectorAll('.screen').forEach((s) => s.classList.remove('active'));
  $('screen-' + name).classList.add('active');
  window.scrollTo({ top: 0 });
  // mount map into a map slot if this screen has one
  const slot = $('screen-' + name).querySelector('.map-slot');
  const m = ensureMap();
  if (slot && m) {
    if (m.getContainer().parentElement !== slot) slot.appendChild(m.getContainer());
    setTimeout(() => m.invalidateSize(), 60);
  }
}

// ------------------------------------------------------------------ home
async function loadHome() {
  const list = $('homeList');
  list.innerHTML = '';
  let routes = [];
  try {
    const d = await api('/api/routes');
    routes = d.routes || [];
  } catch (e) { /* ignore */ }
  if (!routes.length) {
    list.innerHTML = `<div class="card small muted" style="text-align:center; padding:26px;">
      No routes yet. Tap <b>New route</b> to get started.</div>`;
    return;
  }
  for (const r of routes) {
    const row = el('div', 'card route-row');
    row.innerHTML = `
      <div class="rtext">
        <b>${esc(r.name)}</b>
        <span>${r.stops} stops · ${r.createdAt ? new Date(r.createdAt).toLocaleDateString() : ''}</span>
      </div>
      <button class="btn" data-open="${esc(r.id)}">Open</button>`;
    row.querySelector('[data-open]').addEventListener('click', () => openRoute(r.id));
    list.appendChild(row);
  }
}

async function openRoute(id) {
  try {
    const d = await api('/api/routes/' + id);
    state.currentRoute = d.route;
    state.currentRouteId = id;
    state.runIndex = 0;
    renderResult();
    showScreen('result');
  } catch (e) { toast(e.message); }
}

// ------------------------------------------------------------------ import
function openImport() {
  state.draft = { name: '', addresses: [] };
  $('addrText').value = '';
  $('routeName').value = '';
  showScreen('import');
}

function parseCSV(text) {
  const rows = [];
  let row = [], field = '', inQ = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (inQ) {
      if (c === '"') {
        if (text[i + 1] === '"') { field += '"'; i++; } else inQ = false;
      } else field += c;
    } else {
      if (c === '"') inQ = true;
      else if (c === ',') { row.push(field); field = ''; }
      else if (c === '\n' || c === '\r') {
        if (c === '\r' && text[i + 1] === '\n') i++;
        row.push(field); field = '';
        if (row.some((x) => x.trim() !== '')) rows.push(row);
        row = [];
      } else field += c;
    }
  }
  if (field !== '' || row.length) { row.push(field); if (row.some((x) => x.trim() !== '')) rows.push(row); }
  return rows;
}

function parseInput(text) {
  text = text.replace(/^\uFEFF/, '').trim();
  if (!text) return [];
  const hasComma = text.includes(',');
  const hasTab = text.includes('\t');
  const lines = text.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  const out = [];
  if (hasComma || hasTab) {
    const rows = parseCSV(text);
    let start = 0;
    if (rows.length && /address|street|location|name/i.test(rows[0].join(' '))) start = 1;
    for (let i = start; i < rows.length; i++) {
      const joined = rows[i].join(' ').replace(/\s+/g, ' ').trim();
      if (joined) out.push(joined);
    }
  } else {
    lines.forEach((l) => out.push(l));
  }
  return out;
}

const SAMPLE = `Ludington Park, Escanaba, MI 49829
City Hall, 410 Ludington St, Escanaba, MI
Escanaba Public Library, 400 Ludington St, Escanaba, MI
Bonifas Art Center, 700 1st Ave S, Escanaba, MI
OSF St. Francis Hospital, 3401 Ludington St, Escanaba, MI
Escanaba High School, 500 S 18th St, Escanaba, MI
Bay College, 2001 N Lincoln Rd, Escanaba, MI
Walmart Supercenter, 601 N Lincoln Rd, Escanaba, MI
Delta Plaza Mall, 301 N Lincoln Rd, Escanaba, MI
Sayklly's Confectionery, 1304 Ludington St, Escanaba, MI`;

async function doGeocode() {
  const raw = $('addrText').value;
  const addresses = parseInput(raw);
  if (addresses.length < 2) { toast('Enter at least 2 addresses'); return; }
  if (addresses.length > 60) { toast('Max 60 stops per route — split into multiple routes'); return; }
  state.draft = {
    name: $('routeName').value.trim() || ('Route ' + new Date().toLocaleDateString()),
    addresses,
  };
  $('ovGeocode').classList.add('show');
  const items = addresses.map((a, i) => ({ id: 'd' + i, address: a }));
  const t0 = Date.now();
  const estMs = items.length * 1150 + 800;
  const prog = setInterval(() => {
    const pct = Math.min(99, Math.round((Date.now() - t0) / estMs * 100));
    $('ovGeocodeBar').style.width = pct + '%';
    $('ovGeocodeText').textContent = 'Found ~' + Math.max(1, Math.round(pct / 100 * items.length)) + ' of ' + items.length + '…';
  }, 250);
  try {
    const d = await api('/api/geocode', {
      method: 'POST',
      body: JSON.stringify({ items }),
    });
    clearInterval(prog);
    state.geocoded = d.results;
    $('ovGeocode').classList.remove('show');
    renderReview();
    showScreen('review');
  } catch (e) {
    clearInterval(prog);
    $('ovGeocode').classList.remove('show');
    toast(e.message);
  }
}

// ------------------------------------------------------------------ review
function reviewChips() {
  const g = state.geocoded;
  const ok = g.filter((x) => x.ok).length;
  const bad = g.length - ok;
  $('reviewChips').innerHTML = `
    <div class="chip info"><span class="num">${g.length}</span><span class="lab">addresses</span></div>
    <div class="chip good"><span class="num">${ok}</span><span class="lab">found</span></div>
    ${bad ? `<div class="chip warn"><span class="num">${bad}</span><span class="lab">not found</span></div>` : ''}`;
}

function renderReview() {
  reviewChips();
  const list = $('reviewList');
  list.innerHTML = '';
  state.geocoded.forEach((g, i) => {
    const li = el('li');
    const badge = g.ok
      ? `<span class="badge ok">found</span>`
      : `<span class="badge err">not found</span>`;
    const sub = g.ok ? shortAddr(g.displayName) : (g.error || '');
    li.innerHTML = `
      <div class="pin">${i + 1}</div>
      <div class="stext">
        <div class="addr">${esc(shortAddr(g.address))}</div>
        <div class="sub">${esc(sub)}</div>
      </div>
      ${badge}
      <button class="btn ghost" data-edit="${i}" style="padding:6px 8px; font-size:13px;">✎</button>
      <button class="btn ghost" data-rm="${i}" style="padding:6px 8px; font-size:13px; color:var(--red);">✕</button>`;
    li.querySelector('[data-rm]').addEventListener('click', () => {
      state.geocoded.splice(i, 1);
      renderReview();
    });
    li.querySelector('[data-edit]').addEventListener('click', () => {
      const a = prompt('Edit address:', g.address);
      if (a != null && a.trim()) { g.address = a.trim(); regeocode(i); }
    });
    list.appendChild(li);
  });
}

async function regeocode(i) {
  const g = state.geocoded[i];
  $('ovGeocode').classList.add('show');
  $('ovGeocodeBar').style.width = '50%';
  $('ovGeocodeText').textContent = 'Looking up ' + shortAddr(g.address) + '…';
  try {
    const d = await api('/api/geocode', { method: 'POST', body: JSON.stringify({ items: [{ id: 'x', address: g.address }] }) });
    state.geocoded[i] = Object.assign(g, d.results[0], { id: g.id });
  } catch (e) { toast(e.message); }
  $('ovGeocode').classList.remove('show');
  renderReview();
}

function setupOptions() {
  $('optRoundtrip').checked = state.options.roundtrip;
  $('optLeft').checked = state.options.minimizeLeftTurns;
  $('optSide').checked = state.options.preferPassengerSide;
  $('leftStrengthWrap').style.display = state.options.minimizeLeftTurns ? '' : 'none';
  $('sideStrengthWrap').style.display = state.options.preferPassengerSide ? '' : 'none';
  segSelect('leftSeg', state.options.leftStrength);
  segSelect('sideSeg', state.options.sideStrength);
}
function segSelect(id, val) {
  document.querySelectorAll('#' + id + ' button').forEach((b) => b.classList.toggle('on', b.dataset.v === val));
}

// ------------------------------------------------------------------ optimize
async function doOptimize() {
  const ok = state.geocoded.filter((g) => g.ok);
  if (ok.length < 2) { toast('Need at least 2 addresses that were found'); return; }
  state.options = {
    roundtrip: $('optRoundtrip').checked,
    minimizeLeftTurns: $('optLeft').checked,
    leftStrength: currentSeg('leftSeg'),
    preferPassengerSide: $('optSide').checked,
    sideStrength: currentSeg('sideSeg'),
  };
  const stops = ok.map((g) => ({ id: g.id, address: g.address, label: shortAddr(g.address), lat: g.lat, lon: g.lon }));
  $('ovOptimize').classList.add('show');
  const t0 = Date.now();
  const msgs = ['Computing travel times…', 'Optimizing stop order…', 'Evaluating on the road network…', 'Applying driver rules…', 'Polishing route…'];
  let mi = 0;
  const msgTimer = setInterval(() => {
    mi = (mi + 1) % msgs.length;
    $('ovOptimizeText').textContent = msgs[mi];
  }, 4000);
  const tTimer = setInterval(() => {
    $('ovOptimizeElapsed').textContent = 'Elapsed: ' + Math.round((Date.now() - t0) / 1000) + 's';
  }, 1000);
  try {
    const d = await api('/api/optimize', { method: 'POST', body: JSON.stringify({ stops, options: state.options }) });
    clearInterval(msgTimer); clearInterval(tTimer);
    $('ovOptimize').classList.remove('show');
    const payload = {
      id: nid(),
      name: state.draft.name,
      createdAt: Date.now(),
      stops: stops.map((s) => ({ id: s.id, address: s.address, label: s.label, lat: s.lat, lon: s.lon })),
      options: state.options,
      route: d.route,
      log: {},
    };
    await api('/api/routes', { method: 'POST', body: JSON.stringify(payload) });
    state.currentRoute = payload;
    state.currentRouteId = payload.id;
    state.runIndex = 0;
    renderResult();
    showScreen('result');
    toast('Route optimized & saved');
  } catch (e) {
    clearInterval(msgTimer); clearInterval(tTimer);
    $('ovOptimize').classList.remove('show');
    toast(e.message);
  }
}
function currentSeg(id) {
  let v = 'med';
  document.querySelectorAll('#' + id + ' button').forEach((b) => { if (b.classList.contains('on')) v = b.dataset.v; });
  return v;
}

// ------------------------------------------------------------------ result
function sideLabel(st) {
  if (st.side === 'passenger') return 'Passenger side (right)';
  if (st.side === 'driver') return 'Driver side (left)';
  return 'Side unknown';
}
function sideBadge(st) {
  if (st.side === 'passenger') return '<span class="badge pass">PASS</span>';
  if (st.side === 'driver') return '<span class="badge drv">DRV</span>';
  return '<span class="badge unk">?</span>';
}
function statusLabel(s) {
  return { picked_up: 'Picked up', missed: 'Missed', skipped: 'Skipped', pending: 'Pending' }[s] || 'Pending';
}

function renderResult() {
  const r = state.currentRoute.route;
  const st = state.currentRoute.stops;
  $('resultTitle').textContent = state.currentRoute.name;
  const pass = r.stops.filter((s) => s.side === 'passenger').length;
  const drv = r.stops.filter((s) => s.side === 'driver').length;
  const opts = state.currentRoute.options || {};
  const ruleBits = [];
  if (opts.roundtrip) ruleBits.push('round trip');
  if (opts.minimizeLeftTurns) ruleBits.push('fewer left turns');
  if (opts.preferPassengerSide) ruleBits.push('passenger side');
  $('resultSub').textContent = st.length + ' stops · ' + (ruleBits.length ? ruleBits.join(' · ') : 'fastest route');
  $('resultChips').innerHTML = `
    <div class="chip info"><span class="num">${st.length}</span><span class="lab">stops</span></div>
    <div class="chip info"><span class="num">${fmtDur(r.duration)}</span><span class="lab">est. time</span></div>
    <div class="chip info"><span class="num">${fmtDist(r.distance)}</span><span class="lab">distance</span></div>
    <div class="chip warn"><span class="num">${r.leftTurns}</span><span class="lab">left turns</span></div>
    <div class="chip good"><span class="num">${pass}</span><span class="lab">pass. side</span></div>`;
  drawResultMap(r);
  const list = $('resultList');
  list.innerHTML = '';
  for (const s of r.stops) {
    const li = el('li');
    const leftTurns = (r.legs.find((l) => l.to === s.order) || {}).left || 0;
    li.innerHTML = `
      <div class="pin">${s.order}</div>
      <div class="stext">
        <div class="addr">${esc(shortAddr(s.address))}</div>
        <div class="sub">${esc(sideLabel(s))}${s.far ? ' · verify' : ''} · ${leftTurns} left turn${leftTurns === 1 ? '' : 's'} on approach</div>
      </div>
      ${sideBadge(s)}`;
    li.addEventListener('click', () => {
      const ll = s.snapped ? [s.snapped[0], s.snapped[1]] : [s.lat, s.lon];
      ensureMap().setView(ll, 17);
      stopLayer.eachLayer((mk) => { if (mk.getLatLng().lat === ll[0] && mk.getLatLng().lng === ll[1]) mk.openPopup(); });
    });
    list.appendChild(li);
  }
}

function exportCSV(kind) {
  if (!state.currentRouteId) return;
  const url = '/api/export/' + state.currentRouteId + '/' + (kind === 'tracking' ? 'tracking.csv' : 'route.csv');
  fetch(url, { headers: teamKey ? { 'X-Team-Key': teamKey } : {} })
    .then((res) => {
      if (!res.ok) throw new Error('HTTP ' + res.status);
      return res.blob();
    })
    .then((blob) => {
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = '';
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 5000);
    })
    .catch((e) => toast('Export failed: ' + e.message));
}

// ------------------------------------------------------------------ run
function startRun() {
  state.runIndex = firstPendingIndex();
  renderRun();
  showScreen('run');
}
function firstPendingIndex() {
  const r = state.currentRoute.route;
  for (let i = 0; i < r.stops.length; i++) {
    const rec = state.currentRoute.log[r.stops[i].id];
    if (!rec || rec.status === 'pending') return i;
  }
  return 0;
}
function progressCounts() {
  const log = state.currentRoute.log || {};
  let done = 0;
  for (const s of state.currentRoute.route.stops) {
    const rec = log[s.id];
    if (rec && rec.status !== 'pending') done++;
  }
  return { done, total: state.currentRoute.route.stops.length };
}

function renderRun() {
  const r = state.currentRoute.route;
  const idx = Math.min(Math.max(state.runIndex, 0), r.stops.length - 1);
  state.runIndex = idx;
  const s = r.stops[idx];
  const rec = state.currentRoute.log[s.id] || {};
  const { done, total } = progressCounts();
  $('runTitle').textContent = state.currentRoute.name;
  updateDriverUI();
  $('runProgressBar').style.width = Math.round(done / total * 100) + '%';
  $('runProgressText').textContent = `${done} of ${total} stops handled`;
  $('curOrder').textContent = s.order;
  $('curTotal').textContent = total;
  $('curAddr').textContent = s.address;
  const sideLine = $('curSide');
  if (s.side === 'passenger') { sideLine.textContent = '🟢 Passenger side — approach with bin on the right'; sideLine.className = 'side-line pass'; }
  else if (s.side === 'driver') { sideLine.textContent = '🟡 Driver side — bin will be on the left'; sideLine.className = 'side-line drv'; }
  else { sideLine.textContent = '⚪ Side unknown — check when you arrive'; sideLine.className = 'side-line'; }
  $('curNote').value = rec.note || '';
  $('prevStopBtn').disabled = idx === 0;
  $('nextStopBtn').disabled = idx === r.stops.length - 1;
  drawRunMap(r, idx);
  renderRunList(idx);
}

function renderRunList(currentIdx) {
  const r = state.currentRoute.route;
  const list = $('runList');
  list.innerHTML = '';
  r.stops.forEach((s, i) => {
    const rec = state.currentRoute.log[s.id];
    const status = rec ? rec.status : 'pending';
    const li = el('li');
    li.style.cursor = 'pointer';
    let cls = '';
    if (i === currentIdx) cls = 'now';
    else if (status === 'picked_up') cls = 'done';
    else if (status === 'missed') cls = 'missed';
    else if (status === 'skipped') cls = 'skipped';
    li.innerHTML = `
      <div class="pin ${cls}">${s.order}</div>
      <div class="stext">
        <div class="addr">${esc(shortAddr(s.address))}</div>
        <div class="sub">${esc(statusLabel(status))}${rec && rec.note ? ' · ' + esc(rec.note) : ''}</div>
      </div>
      ${sideBadge(s)}`;
    li.addEventListener('click', () => { state.runIndex = i; renderRun(); });
    list.appendChild(li);
  });
}

async function logStop(status) {
  if (!getDriver() && !promptDriver()) { toast('Driver name is required to log pickups'); return; }
  const r = state.currentRoute.route;
  const idx = state.runIndex;
  const s = r.stops[idx];
  const note = $('curNote').value.trim();
  const entry = { status, time: new Date().toISOString(), note: note || '', driver: getDriver() };
  state.currentRoute.log[s.id] = entry;
  try {
    const d = await api('/api/routes/' + state.currentRouteId + '/log', {
      method: 'POST',
      body: JSON.stringify({ log: { [s.id]: entry } }),
    });
    if (d && d.updatedAt) state.currentRoute.updatedAt = d.updatedAt;
  } catch (e) { toast('Could not save: ' + e.message); }
  // advance
  if (idx < r.stops.length - 1) {
    state.runIndex = idx + 1;
    renderRun();
  } else {
    renderRun();
    toast('Route complete 🎉');
  }
}

function refreshRun() {
  if (!state.currentRouteId) return;
  const onRun = document.querySelector('#screen-run').classList.contains('active');
  if (!onRun) return;
  api('/api/routes/' + state.currentRouteId)
    .then((d) => {
      if (d.route && d.route.updatedAt && state.currentRoute.updatedAt && d.route.updatedAt > state.currentRoute.updatedAt) {
        const note = $('curNote').value;
        state.currentRoute = d.route;
        renderRun();
        $('curNote').value = note;
        toast('Synced with other drivers');
      }
    })
    .catch(() => {});
}

// ------------------------------------------------------------------ wiring
document.addEventListener('DOMContentLoaded', () => {
  loadHome();
  updateDriverUI();

  // --- PWA: service worker + install prompt ---
  if ('serviceWorker' in navigator && location.protocol === 'https:') {
    navigator.serviceWorker.register('/sw.js').catch(() => {});
  }
  let deferredPrompt = null;
  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredPrompt = e;
    const b = $('installBtn');
    if (b) b.style.display = 'inline-flex';
  });
  $('installBtn').addEventListener('click', async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      await deferredPrompt.userChoice;
      deferredPrompt = null;
      $('installBtn').style.display = 'none';
    } else {
      toast('Use your browser menu → “Add to Home Screen”');
    }
  });
  $('driverChip').addEventListener('click', () => { if (!getDriver()) promptDriver(); else if (confirm('Change driver? Current: ' + getDriver())) promptDriver(); });

  // --- multi-driver sync: poll for changes from other devices ---
  setInterval(refreshRun, 15000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) refreshRun(); });

  $('homeBtn').addEventListener('click', () => { loadHome(); showScreen('home'); });
  $('newRouteBtn').addEventListener('click', openImport);
  $('backHomeBtn').addEventListener('click', () => { loadHome(); showScreen('home'); });

  // import screen
  $('sampleBtn').addEventListener('click', () => { $('addrText').value = SAMPLE; });
  $('fileInput').addEventListener('change', (e) => {
    const f = e.target.files && e.target.files[0];
    if (!f) return;
    const rd = new FileReader();
    rd.onload = () => { $('addrText').value = String(rd.result || ''); };
    rd.readAsText(f);
  });
  $('continueImportBtn').addEventListener('click', doGeocode);

  // review screen
  $('addRowBtn').addEventListener('click', () => {
    const a = prompt('Address:');
    if (a && a.trim()) {
      state.geocoded.push({ id: nid(), address: a.trim(), ok: false, error: 'not looked up yet' });
      regeocode(state.geocoded.length - 1);
    }
  });
  $('optLeft').addEventListener('change', (e) => { $('leftStrengthWrap').style.display = e.target.checked ? '' : 'none'; });
  $('optSide').addEventListener('change', (e) => { $('sideStrengthWrap').style.display = e.target.checked ? '' : 'none'; });
  document.querySelectorAll('#leftSeg button').forEach((b) => b.addEventListener('click', () => segSelect('leftSeg', b.dataset.v)));
  document.querySelectorAll('#sideSeg button').forEach((b) => b.addEventListener('click', () => segSelect('sideSeg', b.dataset.v)));
  $('optimizeBtn').addEventListener('click', doOptimize);
  setupOptions();

  // result screen
  $('startRouteBtn').addEventListener('click', startRun);
  $('exportTrackingBtn').addEventListener('click', () => exportCSV('tracking'));
  $('exportRouteBtn').addEventListener('click', () => exportCSV('route'));

  // run screen
  $('actPicked').addEventListener('click', () => logStop('picked_up'));
  $('actMissed').addEventListener('click', () => logStop('missed'));
  $('actSkip').addEventListener('click', () => logStop('skipped'));
  $('prevStopBtn').addEventListener('click', () => { state.runIndex = Math.max(0, state.runIndex - 1); renderRun(); });
  $('nextStopBtn').addEventListener('click', () => {
    const r = state.currentRoute.route;
    state.runIndex = Math.min(r.stops.length - 1, state.runIndex + 1);
    renderRun();
  });
  $('runExportBtn').addEventListener('click', () => exportCSV('tracking'));
  $('finishBtn').addEventListener('click', () => {
    exportCSV('tracking');
    toast('Tracking CSV exported');
  });
});
