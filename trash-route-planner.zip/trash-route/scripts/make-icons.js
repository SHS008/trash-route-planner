'use strict';
/*
 * Regenerates the PWA icons from inline SVGs using sharp.
 * Usage: npm i --no-save sharp && node scripts/make-icons.js
 */
const fs = require('fs');
const path = require('path');
const sharp = require('sharp');

const outDir = path.join(__dirname, '..', 'public', 'icons');
fs.mkdirSync(outDir, { recursive: true });

// glyph drawn inside a 512x512 viewBox (trash bin)
const GLYPH = `
  <rect x="168" y="220" width="176" height="224" rx="28"/>
  <rect x="132" y="200" width="248" height="28" rx="14"/>
  <rect x="240" y="144" width="32" height="60" rx="10"/>
  <rect x="196" y="252" width="120" height="16" rx="8"/>
  <rect x="196" y="292" width="120" height="16" rx="8"/>
  <rect x="196" y="332" width="120" height="16" rx="8"/>`;

const anySVG = `<svg xmlns="http://www.w3.org/2000/svg" width="512" height="512" viewBox="0 0 512 512">
  <rect width="512" height="512" rx="116" fill="#ffb454"/>
  <g fill="#14181f">${GLYPH}</g>
</svg>`;

const maskableSVG = `<svg xmlns="http://www.w3.org/2000/svg" width="512" height="512" viewBox="0 0 512 512">
  <rect width="512" height="512" fill="#ffb454"/>
  <g transform="translate(87.04,87.04) scale(0.66)"><g fill="#14181f">${GLYPH}</g></g>
</svg>`;

async function render(svg, file, size) {
  await sharp(Buffer.from(svg)).resize(size, size).png().toFile(path.join(outDir, file));
  console.log('wrote', file, size + 'px');
}

(async () => {
  await render(anySVG, 'icon-512.png', 512);
  await render(anySVG, 'icon-192.png', 192);
  await render(anySVG, 'apple-touch-icon.png', 180);
  await render(anySVG, 'favicon.png', 48);
  await render(maskableSVG, 'maskable-512.png', 512);
  await render(maskableSVG, 'maskable-192.png', 192);
  console.log('done');
})();
