'use strict';
/*
 * Copies Leaflet's dist files from node_modules into public/vendor so the app
 * works without a build step (and after a fresh `npm install`).
 * Run via: npm run vendor  (also wired into postinstall)
 */
const fs = require('fs');
const path = require('path');

const src = path.join(__dirname, '..', 'node_modules', 'leaflet', 'dist');
const dst = path.join(__dirname, '..', 'public', 'vendor', 'leaflet');

if (!fs.existsSync(path.join(src, 'leaflet.js'))) {
  console.error('Leaflet not found in node_modules — run `npm install` first.');
  process.exit(1);
}

fs.mkdirSync(dst, { recursive: true });
fs.copyFileSync(path.join(src, 'leaflet.js'), path.join(dst, 'leaflet.js'));
fs.copyFileSync(path.join(src, 'leaflet.css'), path.join(dst, 'leaflet.css'));
fs.cpSync(path.join(src, 'images'), path.join(dst, 'images'), { recursive: true });
console.log('Leaflet vendored to public/vendor/leaflet');
