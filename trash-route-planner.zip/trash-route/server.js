'use strict';
const path = require('path');
const express = require('express');
const { geocodeAddresses } = require('./lib/geocode');
const { optimize } = require('./lib/optimize');
const store = require('./lib/store');
const { trackingCSV, routeCSV } = require('./lib/csv');

const app = express();
app.use(express.json({ limit: '6mb' }));

// ---- health (always public, used by hosts/uptime checks) ----
app.get('/api/health', (req, res) => res.json({ ok: true, ts: Date.now() }));

// ---- optional shared team key ----
const TEAM_KEY = process.env.TEAM_KEY || '';
app.use('/api', (req, res, next) => {
  if (!TEAM_KEY) return next();
  if ((req.get('x-team-key') || '') === TEAM_KEY) return next();
  return res.status(401).json({ error: 'team_key_required' });
});

app.use(express.static(path.join(__dirname, 'public')));

// ---------------------------------------------------------------- geocoding
app.post('/api/geocode', async (req, res) => {
  const items = (req.body && req.body.items) || [];
  if (!Array.isArray(items) || !items.length) return res.status(400).json({ error: 'no addresses provided' });
  if (items.length > 200) return res.status(400).json({ error: 'max 200 addresses per batch' });
  try {
    const results = await geocodeAddresses(items);
    res.json({ results });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ---------------------------------------------------------------- optimize
app.post('/api/optimize', async (req, res) => {
  const body = req.body || {};
  const stops = body.stops;
  const options = body.options || {};
  if (!Array.isArray(stops) || stops.length < 2) {
    return res.status(400).json({ error: 'need at least 2 geocoded stops' });
  }
  try {
    const result = await optimize(stops, options);
    res.json({ route: result });
  } catch (e) {
    console.error('optimize error:', e.message);
    res.status(400).json({ error: e.message });
  }
});

// ---------------------------------------------------------------- persistence
app.post('/api/routes', (req, res) => {
  const body = req.body || {};
  if (!body.id) return res.status(400).json({ error: 'id required' });
  const payload = {
    id: body.id,
    name: body.name || 'Route',
    createdAt: body.createdAt || Date.now(),
    updatedAt: Date.now(),
    stops: body.stops || [],
    options: body.options || {},
    route: body.route || null,
    log: body.log || {},
  };
  store.saveRoute(body.id, payload);
  res.json({ ok: true, id: body.id });
});

app.get('/api/routes', (req, res) => {
  res.json({ routes: store.listRoutes() });
});

app.get('/api/routes/:id', (req, res) => {
  const r = store.loadRoute(req.params.id);
  if (!r) return res.status(404).json({ error: 'not found' });
  res.json({ route: r });
});

app.post('/api/routes/:id/log', async (req, res) => {
  try {
    const r = await store.updateLog(req.params.id, (req.body && req.body.log) || {});
    res.json({ ok: true, updatedAt: r.updatedAt });
  } catch (e) {
    res.status(e.status || 500).json({ error: e.message });
  }
});

// ---------------------------------------------------------------- export
app.get('/api/export/:id/tracking.csv', (req, res) => {
  const r = store.loadRoute(req.params.id);
  if (!r || !r.route) return res.status(404).json({ error: 'route not found' });
  const csv = trackingCSV(r.route, r.log);
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="${storeName(r)}-tracking.csv"`);
  res.send('\uFEFF' + csv);
});

app.get('/api/export/:id/route.csv', (req, res) => {
  const r = store.loadRoute(req.params.id);
  if (!r || !r.route) return res.status(404).json({ error: 'route not found' });
  const csv = routeCSV(r.route);
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="${storeName(r)}-route.csv"`);
  res.send('\uFEFF' + csv);
});

function storeName(r) {
  return String(r.name || r.id || 'route').replace(/[^a-z0-9_-]/gi, '_').slice(0, 60) || 'route';
}

const PORT = process.env.PORT || 3000;
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Trash Route Planner listening on http://0.0.0.0:${PORT}`);
  if (TEAM_KEY) console.log('Team key protection: ENABLED');
  else console.log('Team key protection: DISABLED (set TEAM_KEY to enable)');
});
