# 🚀 Taking Trash Route Planner live

The goal: a **public URL** your drivers open on their phones (no sandbox, no
access token). This is the one part I can't do *for* you — publishing requires
**your** account at a hosting service — but I've made the app deploy-ready and
the steps below are copy-paste simple. If you get stuck at any step, tell me
where you are and I'll walk you through it.

---

## What you'll need

1. **The app code** — this folder. The easiest way to move it around is a free
   GitHub repository.
2. **One free (or ~$5/mo) hosting account** — options below.

---

## Step 0 — Put the code on GitHub (recommended)

1. Create a free account at github.com, then **New repository** (private is fine).
2. Upload this folder's contents. Skip `node_modules/` and `data/` — they're
   already listed in `.gitignore` and must NOT be uploaded.
3. That's it — every host below can now deploy straight from your repo.

---

## Option A — Railway (easiest)

1. Sign up at railway.app (with GitHub), **New Project → Deploy from GitHub repo**.
2. Railway auto-detects the app (it has a `Dockerfile`).
3. Add a **Volume** (project → Settings → Volumes) mounted at `/data`.
4. Add environment variables (Variables):
   - `TEAM_KEY` = a secret your drivers will all enter
   - `DATA_DIR` = `/data`
5. Railway gives you a URL like `https://yourapp.up.railway.app` — done.

## Option B — Render

1. render.com → **New → Web Service** → connect your repo.
2. Build command `npm ci`, start command `npm start`.
3. For data that survives redeploys, attach a **Persistent Disk** (small extra
   cost) mounted at `/data`, and set `DATA_DIR=/data`.
4. Set `TEAM_KEY`.
5. You get a URL like `https://yourapp.onrender.com`.

## Option C — Any VPS with Docker (most control)

On any Linux server (DigitalOcean, Hetzner, Linode, a spare PC, etc.):

```bash
git clone https://github.com/YOU/YOUR-REPO.git app
cd app
docker build -t trash-route .
docker run -d --name trash-route -p 80:3000 \
  -v /opt/trash-route-data:/data \
  -e TEAM_KEY=your-secret \
  --restart unless-stopped \
  trash-route
```

The app is then at `http://your-server-ip` (add HTTPS with Caddy/Traefik or a
provider firewall; many VPS panels do this in one click).

## Option D — No Docker

```bash
npm install
DATA_DIR=./data TEAM_KEY=your-secret npm start
```

Make sure `./data` lives on a persistent disk.

---

## Configure it

| Variable | What it does | Recommended |
|---|---|---|
| `TEAM_KEY` | Shared password all drivers enter. Without it, **anyone** with the URL can see/change routes. | **Set it.** |
| `DATA_DIR` | Where routes & pickup logs are stored. Must be a persistent disk/volume or data is lost on redeploy. | `/data` |
| `PORT` | Port to listen on (default 3000). | Leave default. |

---

## Hand it to your drivers

1. Text them the public URL. It opens in any phone browser.
2. **Install it like an app:**
   - Android Chrome → menu ⋮ → **Add to Home screen** (or the in-app **📲 Install** button).
   - iPhone Safari → Share → **Add to Home Screen**.
3. It now opens **full-screen with an icon**, and works offline once it's been
   loaded (routes sync when back online).
4. Each driver taps **👤 Set driver** and enters their name — every pickup they
   log is stamped with that name on the exported tracking sheet.
5. All drivers on the same URL see each other's progress (the app syncs every
   15 seconds).

---

## Notes & limits

- **HTTPS is required** for install + offline. All hosts above provide HTTPS by
  default.
- Geocoding and routing use free **OpenStreetMap** services (Nominatim + OSRM
  demo). Great for a small fleet; for heavy daily use I can swap in a commercial
  provider or self-hosted OSRM — just ask.
- Want **per-driver accounts** instead of a shared key, or a route **assigned**
  to each driver? I can add that next.
