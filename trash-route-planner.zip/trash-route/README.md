# 🗑️ Trash Route Planner

A mobile-friendly web app for **trash pickup companies**. Upload a list of
addresses, let the app plan the route using your driver rules, drive it while
logging every pickup, and export a tracking spreadsheet at the end.

**Built-in map (no Google Maps needed)** — the driver follows the route right
in the app, with turn-by-turn order, per-stop "which side of the road the bin
is on" flags, and a left-turn counter.

**Installable as an app (PWA)** — add it to a phone's home screen and it opens
full-screen with an icon and offline support. **Central tracking** — all
drivers share one server, so pickups sync across the whole crew, and every
entry on the export is stamped with the driver's name. See [DEPLOY.md](DEPLOY.md)
to publish it and get a public URL.

---

## How to use it

The app is running live in the preview. The flow is four steps:

### 1. Import addresses
Tap **New route**, then either:
- **Paste** one address per line, or paste a spreadsheet column/CSV
  (`Street, City, State, ZIP` works), or
- **Upload** a `.csv` / `.txt` file, or
- Tap **Load sample** to try it with real Escanaba addresses.

Tap **Find addresses** — each address is geocoded on OpenStreetMap (~1 second
per address).

### 2. Apply driver rules
On the review screen you can remove/fix any address that wasn't found, then set:
- **Round trip** — start and end at the same address (depot first & last).
- **Minimize left turns** — trades a little time for fewer across-traffic left
  turns (Amazon-style), with Light / Medium / Strong strength.
- **Prefer passenger-side stops** — tries to approach each address so the bin
  is on the **right (passenger) side** for a right-hand-drive collection
  operation.

Default is the **fastest** route; the toggles bias it toward your rules.

### 3. Drive the optimized route
Tap **Start route / log pickups**. You get:
- A map with your numbered route line (green = traveled, orange = remaining),
- The current stop, the **side-of-road flag**, and one-tap buttons —
  **✓ Picked up / ✗ Missed / ⏭ Skip** — plus an optional note per stop,
- Tap any stop in the list to jump to it.

### 4. Export
- **Tracking CSV** (spreadsheet) — one row per address: stop #, status
  (picked up / missed / skipped / pending), address, coordinates, side of
  road, approach bearing, left turns on approach, pickup timestamp, and note.
- **Route order CSV** — the pre-determined stop order with coordinates, for
  your records or any other tool.

Routes are saved on the server, so you can reopen a route later and keep
logging.

---

## What's under the hood

| Piece | What it does |
|---|---|
| **Geocoding** | OpenStreetMap Nominatim — turns addresses into coordinates. |
| **Travel times** | OSRM — real road-network distances/durations (not straight lines). |
| **Optimizer** | Custom solver (nearest-neighbor + 2-opt + Or-opt) over the duration matrix, then local-search refinement evaluated on the real road network. |
| **Left turns** | Counted from OSRM's turn-by-turn maneuver data. |
| **Side of road** | Compares each address to the snapped road position and the direction of travel — in US right-hand traffic, the **right** side is the passenger side. |
| **Map** | Leaflet with a dark basemap (OpenStreetMap + CARTO). |

### Files
```
trash-route/
├── server.js          Express server + API (team-key protected)
├── lib/
│   ├── geocode.js     Nominatim geocoding (rate-limited)
│   ├── optimize.js    Matrix + solver + turn/side analysis + refinement
│   ├── tsp.js         Traveling-salesman solver
│   ├── osrm.js        HTTP helpers
│   ├── csv.js         Tracking (incl. driver) + route CSV export
│   └── store.js       Route persistence (JSON, atomic writes, per-route locks)
├── public/
│   ├── index.html     UI (dark, mobile-first)
│   ├── app.js         Frontend logic (multi-driver sync, PWA, team key)
│   ├── manifest.json  PWA manifest
│   ├── sw.js          Service worker (offline shell)
│   ├── icons/         App icons (192/512 + maskable + favicon)
│   └── vendor/leaflet Map library
├── scripts/           vendor-leaflet.js, make-icons.js
├── Dockerfile         Container for easy deployment
├── DEPLOY.md          Step-by-step "go live" guide
└── data/              Saved routes (mount a persistent volume in prod)
```

### API
- `POST /api/geocode` — geocode `{items:[{id, address}]}`
- `POST /api/optimize` — optimize `{stops, options}`
- `POST /api/routes` / `GET /api/routes` / `GET /api/routes/:id` — save & load
- `POST /api/routes/:id/log` — merge pickup log entries
- `GET /api/export/:id/tracking.csv` — pickup tracking spreadsheet
- `GET /api/export/:id/route.csv` — pre-determined route order

---

## Notes & limits

- **🚀 To publish it** (get a public URL your drivers can use), follow
  [DEPLOY.md](DEPLOY.md). Set a `TEAM_KEY` and mount a persistent volume for
  `DATA_DIR`.
- **Up to 60 stops per route** (keeps the optimizer fast and accurate). For a
  full day, split the list into multiple routes.
- Uses the free **OSRM demo server** and **Nominatim** (public, usage-policy
  limited). For production at scale, swap in a commercial routing/geocoding
  provider.
- "Passenger side" assumes **US right-hand traffic** and a vehicle where the
  passenger sits on the right. Stops more than ~120 m from the nearest road are
  flagged **verify** (side can't be reliably determined).
- The **first** address is the route start; the **last** is the end (or the
  loop-back point for round trips) — put your depot there if you start from one.
